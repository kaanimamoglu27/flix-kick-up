# FLIX DÜELLO: Claude'a yapıştırılacak oyun tarifi

> Bu metnin tamamını Claude'a yapıştır. Aynı mesaja paketteki şu dosyaları da ekle:
> **flix-duello-taslak.jpg** (oynanış taslağı), **flix-logo-kirmizi.png** (logo), **flix-oyuncak-modeli.js** (oyuncağın 3D modeli), **flix-kahraman-modeli.js** (FLIX kahramanının 3D modeli), **app-ikonu-1024.png** (başlangıç ikonu), **altyapi/** klasöründeki dosyalar (açılış ekranı, reklam, satın alma ve iOS iskeleti).

---

Merhaba Claude. Senden **FLIX DÜELLO** adında, iPhone'da dikey oynanan bir 3D spor oyunu yapmanı istiyorum. Ekteki **flix-duello-taslak.jpg** oyunun nasıl görüneceğini gösteren taslak: kamera açısı, arayüz yerleşimi ve renkler bu taslağa yakın olsun. Önce oynanabilir bir prototip yap, sonra aşağıdaki adımlarla geliştirelim.

## 1. Oyunun fikri (tek cümle)

File üstünden 1'e 1 **Flix tenisi**: tüylü Flix oyuncağını ayağınla rakibin sahasına gönder, rakip yere düşürürse sayı senin.

Bu, Flix oyuncağının gerçek hayatta oynanış şekline (iki kişi karşılıklı ayakla sektirir) en yakın oyun. Çocuklar oyuncakla yaptıklarını ekranda görür.

## 2. Karakterler

- Oyuncu ve rakipler **FLIX kahramanı**: ekteki **flix-kahraman-modeli.js** dosyasındaki `hero(skin)` modeli (Flix Arkana oyunundaki FLIX karakteri: kırmızı yuvarlak kafa, laleye benzeyen taç, pelerin, beyaz eldiven, büyük kırmızı ayakkabı). Modeli kullan, bozma. Ayak ve kol pozları `pose(H, {...})` ile. Yüz ifadeleri `R.flixFaces` (happy, blink, shout, hurt).
- Rakipler kostümlü FLIX'ler: **Buzul** (mavi-beyaz), **Ejder** (yeşil-siyah), **Altın** (sarı), **Neon** (pembe). `SKINS` içinde hazır, yenisi aynı alanlarla eklenir. Her rakibin kendi oyun tarzı var (Buzul sabırlı ve lobcu, Ejder sert smaççı, Altın her şeyi karşılar, Neon hızlı ve sinsi).
- Top yerine **Flix oyuncağı** (`makeToy()`) gidip geliyor. Gerçek badminton topu gibi uçar: gövde öne, tüyler arkada. Havada hafif döner.

## 3. Oynanış

- Saha: ortada file, iki yarı saha. Kamera oyuncunun arkasından, yukarıdan ve hafif çapraz bakar (taslaktaki gibi, FOV yaklaşık 50). Kendi sahan aşağıda, rakip yukarıda.
- FLIX kahramanın, oyuncağın düşeceği yere **kendisi koşar** (otomatik hareket). Yerde oyuncağın düşeceği noktada **sarı bir halka** çıkar.
- Oyuncak vuruş mesafesine gelince ekranın sol altında **zamanlama çubuğu** dolar. Ortadaki sarı bölgede vurursan **MÜKEMMEL**: top sert ve isabetli gider. Erken ya da geç vurursan top yavaş ve rastgele gider, çok kaçırırsan oyuncak düşer.
- **Vuruş seçimi (sağ altta, başparmakla):**
  - **SMAÇ** (büyük sarı düğme): sert, alçak, hızlı. Basılı tutup bırakınca gücü artar.
  - **LOB** (yanındaki beyaz düğme): yavaş, yüksek, rakibin arkasına düşer.
  - **Yön:** düğmeye basarken parmağı sola ya da sağa kaydırırsan top o köşeye gider. Kaydırmazsan ortaya.
- Rakip bot aynı kurallarla oynar: koşar, zamanlama hatası yapabilir, zor rakiplerde daha az hata yapar.
- **Sayı:** oyuncak bir sahanın içinde yere düşerse karşı taraf sayı alır. Dışarı düşerse vuran kaybeder. Fileye takılırsa vuran kaybeder.
- **Set:** 11 sayı (10-10'da 2 fark), maç 3 set (2 kazanan alır). Hızlı maç seçeneği: tek set, 7 sayı.
- **Ralli serisi:** uzun rallilerde ekranda "RALLİ 8" sayacı, 10'dan sonra her vuruş ekstra tüy verir.
- **Süper vuruş:** her MÜKEMMEL vuruş sağ alttaki düğmenin çevresindeki halkayı doldurur. Halka dolunca bir sonraki SMAÇ **TÜY FIRTINASI** olur: oyuncak alev izli gider, karşılanması çok zor.

## 4. Modlar

1. **Hızlı Maç:** rastgele rakip, tek set.
2. **Lig:** 8 rakipli lig (Mahalle Ligi, Şehir Ligi, Kıta Ligi, Dünya Kupası). Her lig 7 maç, ilk 2'ye girersen üst lig açılır. Her lig sonunda bir kostüm hediye.
3. **Turnuva:** 8 kişilik eleme ağacı, finali kazanınca kupa ve büyük tüy ödülü.
4. **Arkadaşla (aynı telefonda değil, link ile):** ilk sürümde "Yakında". Online için sunucu gerekir. İkinci aşamada Flix Kick Up'taki gibi WebSocket sunucusu (Render), hızlı eşleşme ve 6 haneli oda kodu ile.
5. **Günlük Meydan Okuma:** her gün bir görev ("3 MÜKEMMEL üst üste", "Ejder'i 11-5 yen").

## 5. Sahalar

Sahalar tüyle açılır, oynanışı değiştirmez, sadece görünüş:
- **Gün Batımı Plajı** (taslaktaki, başlangıç): kum, palmiyeler, şemsiyeler, deniz, güneş.
- **Okul Bahçesi:** beton zemin, tebeşir çizgileri, basketbol potası.
- **Çatı Katı:** İstanbul çatısı, su deposu, Galata uzakta.
- **Gece Stadı:** ışıklar, kalabalık tribün.
- **Kış Parkı:** kar, kardan adam, hafif kar yağışı.

## 6. Ekonomi ve dükkân

- Tüy kazanma: maç kazanma 60, kaybetme 20, MÜKEMMEL başına 2, ralli serisi bonusu, lig/turnuva ödülleri, günlük hediye, ödüllü reklam (tüyleri 2 katı).
- **Dükkân sekmeleri:** Kostümler (FLIX kahraman renkleri), Oyuncaklar (Flix oyuncağının gövde ve tüy renkleri), İzler (oyuncağın uçuş izi), Sahalar.
- Nadirlik ve fiyatlar ev standartlarındaki gibi (bölüm A). Mitik: **Ejderha FLIX** kostümü 15.000 tüy.
- Kaybedince "Kaldığın yerden devam" yok (maç oyunu). Onun yerine maç sonunda **"Tüyleri 2 katına çıkar"** ödüllü reklamı.

## 7. Uygulama içi ürünler (App Store Connect'te aynı kimliklerle açılacak)

| Kimlik | Tür | Fiyat | İçerik |
|---|---|---|---|
| `duello_starter` | Tüketilemez | 2,99 $ | Başlangıç Paketi: 2.500 tüy + Altın FLIX kostümü |
| `duello_noads` | Tüketilemez | 2,99 $ | Reklamsız: tur arası reklamları kaldırır |
| `duello_feathers_500` | Tüketilebilir | 0,99 $ | 500 tüy |
| `duello_feathers_1200` | Tüketilebilir | 1,99 $ | 1.200 tüy |
| `duello_feathers_3500` | Tüketilebilir | 4,99 $ | 3.500 tüy |
| `duello_feathers_8000` | Tüketilebilir | 9,99 $ | 8.000 tüy |
| `duello_feathers_18000` | Tüketilebilir | 19,99 $ | 18.000 tüy |
| `duello_feathers_50000` | Tüketilebilir | 49,99 $ | 50.000 tüy |

## 8. Uygulama bilgileri

- **Ad:** Flix Düello · **Paket kimliği (Bundle ID):** `com.flixtoys.duello` · **SKU:** `duello1` · iPhone, dikey.
- **Alt başlık (TR):** File üstünde 1'e 1 Flix maçı! · **(EN):** 1v1 Flix over the net!
- **Kısa açıklama (TR):** Tüylü FLIX'i fileden rakibinin sahasına gönder! Zamanlamayı tuttur, MÜKEMMEL vuruş yap, smaç ya da lobla köşeye yolla. Ligde yüksel, turnuvada kupayı kaldır, kostümlerini topla.
- **Ekran görüntüleri (6,9" 1290x2796, TR ve EN):** 1 ana ekran, 2 MÜKEMMEL smaç anı, 3 lig tablosu, 4 rakip seçimi (kostümlü FLIX'ler), 5 sahalar, 6 dükkân. Görseller gerçek oyundan alınır, üstüne büyük italik başlık.
- **App ikonu:** pakette başlangıç ikonu var (**app-ikonu-1024.png**: FLIX kahramanı oyuncağa vurmuş, arkada file ve gün batımı). Oyun bitince aynı açıdan gerçek oyun sahnesinden yeniden çiz.

## 8a. Görsel tarz (ayrıntılı)

- **Hava:** sıcak, güneşli, yaz tatili enerjisi. Taslaktaki gün batımı plajı ana kimlik: lacivertten turuncuya ve şeftaliye geçen gökyüzü, alçak güneş, uzun yumuşak gölgeler.
- **Kamera:** oyuncunun arkasından, yaklaşık 20 derece yukarıdan, sahanın tamamı görünür (rakip ekranın üst üçte birinde, file ortada, sen alt üçte birde). Vuruş anında 0.15 saniyelik hafif yakınlaşma, MÜKEMMEL'de 0.25 saniye yavaş çekim. Sayı olunca kamera kısa süre oyuncağın düştüğü yere kayar.
- **Saha:** beyaz bant çizgiler, kırmızı kenar şeridi, lacivert direkler ve sarı top uçlu file direkleri. File siyah ip dokusu, üstte beyaz bant.
- **Kahramanlar:** kalın mürekkep çizgisi (0.018), parlak plastik malzeme (Phong, shininess 70). Vuruşta ezilip uzama, sayı alınca "shout" yüzü ve kollar havada, kaybedince "hurt" yüzü.
- **Oyuncak:** uçarken arkasında ince beyaz iz; MÜKEMMEL vuruşta iz sarı ve kalın, TÜY FIRTINASI'nda turuncu alev izi ve tüylerden kıvılcım.
- **Efektler (abartısız):** vuruş anında 10 ışınlı sarı-beyaz yıldız patlaması (0.2 sn), yere düşüşte kum tozu, sayıda karşı taraf tribününde kısa sevinç. Ekranda aynı anda en fazla 2 büyük yazı.
- **Saha paletleri:** Plaj (kum `#e9cfa0`, deniz `#2a78b8`), Okul Bahçesi (beton `#c9c4bb`, tebeşir beyaz), Çatı Katı (terrakota `#c8643c`, krem duvar), Gece Stadı (koyu çim `#1f6b3a`, beyaz ışık konileri), Kış Parkı (kar `#f4f8ff`, buz mavisi).
- **Arayüz:** skor kartı üstte ortada beyaz kart (taslaktaki gibi: SEN 7 · 2. SET · BUZUL 5, set noktaları renkli). Zamanlama çubuğu sol altta, ortası sarı bölge.

## 8b. Dükkân kataloğu (ilk sürüm)

| Sekme | Ürün | Nadirlik | Fiyat (tüy) | Nasıl açılır |
|---|---|---|---|---|
| Kostüm | Kraliyet FLIX | Sıradan | ücretsiz | başlangıç |
| Kostüm | Buzul | Sıradan | 200 | dükkân |
| Kostüm | Ejder | Nadir | 600 | dükkân / Mahalle Ligi hediyesi |
| Kostüm | Neon | Nadir | 750 | dükkân |
| Kostüm | Plaj Kurtarıcısı (kırmızı şort, düdük) | Destansı | 1.500 | dükkân |
| Kostüm | Altın | Efsane | 3.500 | dükkân / Başlangıç Paketi |
| Kostüm | Ejderha FLIX (kanatlı pelerin, alev taç) | Mitik | 15.000 | dükkân |
| Oyuncak | Klasik, Okyanus, Orman, Gece, Kristal, Lav, Gökkuşağı | Sıradan-Efsane | 150-3.000 | dükkân |
| İz | Beyaz, Tüy, Yıldız, Kalp, Alev, Gökkuşağı | Sıradan-Destansı | 150-1.800 | dükkân |
| Saha | Okul Bahçesi 300, Çatı Katı 800, Gece Stadı 1.500, Kış Parkı 1.800 | | | dükkân |

## 8c. Ekonomi ve reklam ayarları (kodda tek yerde)

```js
const ECON = {win: 60, lose: 20, perfect: 2, rallyBonusFrom: 10, rallyBonus: 3, leagueWin: [300, 500, 800, 1500], cupWin: 1000, daily: [50,75,100,150,200,300,'nadir']};
const AD_CFG = {doubleReward: true, interstitialFirstAfter: 3, interstitialEvery: 3, interstitialMinGapSec: 90, freeFeathersPerDay: 5, freeFeathersAmount: 50, freeFeathersGapMin: 10};
```
Maç sonu ekranı sırası: skor, kazanılan tüy (sayarak dolar), "2 KATINA ÇIKAR ▶" (ödüllü), sağ altta TEKRAR, yanında MENÜ. Tur arası reklam sadece MENÜ/TEKRAR'a basınca, kurala uyuyorsa.

## 9. Yapım sırası

1. **Prototip:** saha, file, iki FLIX, otomatik koşma, zamanlama çubuğu, SMAÇ/LOB, sayı ve set. Bot rakip. Telefonda dene, vuruş hissini ayarla.
2. **Oyun hissi:** sesler, ezilip uzama, kamera sarsıntısı, MÜKEMMEL yazısı, ralli sayacı, süper vuruş.
3. **Ekranlar:** FLIX TOYS presents, Kick Up tarzı ana ekran, nasıl oynanır, maç sonu ekranı, ayarlar, TR/EN.
4. **İçerik:** Lig, Turnuva, Günlük Meydan Okuma, 5 rakip, 5 saha.
5. **Ekonomi:** tüy, dükkân, reklamlar (web'de Flix kartı), satın almalar (web'de DEMO).
6. **Mağaza hazırlığı:** Capacitor iOS paketi (`altyapi/`), ikon, açılış ekranı, ekran görüntüleri, mağaza metni TR/EN.
7. **Sonra:** online maç (sunucu), haftalık turnuva.

**Tahmini iş:** 6 adım, her biri 1-2 Claude oturumu (toplam yaklaşık 8-12 oturum). En zor kısım vuruş hissi ve botun insan gibi hata yapması. Online sonraki aşamada ayrıca 3-4 oturum.

Önce **1. adımla** başla.

---

## A. Flix ev standartları (bütün Flix oyunlarında aynı, bunlara mutlaka uy)

Bu oyun, aynı markanın yayındaki diğer oyunlarıyla (Flix Kick Up, Flix Arkana, Flix Atış, Flix Sen Olsaydın) aynı aileden olacak. Aşağıdaki kurallar o oyunlarda denendi ve kabul edildi.

**Marka**
- **Flix** bir oyuncak markası (flixtoysofficial.com, Amazon'da da satılıyor). Ürün ayakla sektirilen tüylü bir oyuncak: altta yuvarlak kırmızı bir gövde, üstünde yelpaze gibi açılmış **3 yaprak şeklinde tüy (mavi, yeşil, sarı)**. Tüy sayısı her zaman 3, gövde her zaman 1.
- Logo: ekteki **flix-logo-kirmizi.png** (kırmızı zemin üstünde). Ana ekranda, açılışta ve mağaza görsellerinde bu logo kullanılır. Logoyu yeniden çizme, dosyayı kullan.
- Renkler: kırmızı `#e22511`, lacivert `#022753`, sarı `#ffc20e`, mürekkep çizgisi `#1b1330`. Tüyler: mavi `#1f6fd1`, yeşil `#2fa84f`, sarı `#ffc20e`.
- Yazı tipleri: başlık ve rakamlar **Barlow Condensed** (italik, 800-900), metinler **Rubik**. Uygulamada internetsiz çalışsın diye font dosyaları uygulamanın içine konur.
- 3D oyuncak: ekteki **flix-oyuncak-modeli.js** (`makeToy()`). Bunu kullan, bozma. Tüy pivotları `toy.userData.fe` içinde.

**Görünüm**
- Temiz, sevimli **çizgi film (toon) 3D**: koyu ince mürekkep dış çizgisi (`ink()`), yumuşak gölge, sıcak ışık, canlı ama yorucu olmayan renkler.
- **Yapay zekâ yapımı gibi görünmesin.** İstenmeyenler: hazır şablon görünümü, mor-mavi degrade arka planlar, emoji ikonlar, her yerde aynı yuvarlak kartlar, rastgele parlama efektleri, gereksiz kalabalık. Az ama büyük ve net öğeler.
- Animasyonlar hızlı ve abartısız: ekran geçişleri 0.3 saniyenin altında.

**Ekranlar ve akış**
- Açılışta 2 saniyelik **"FLIX TOYS presents"** ekranı. Hazır kodu ekteki `altyapi/intro.html` içinde, `<body>`'nin en başına aynen yapıştırılır. Dokununca geçilir.
- **Kick Up tarzı ana ekran**: kırmızı zemin, üstte Flix logosu, büyük italik oyun adı, ortada oyunun 3D sahnesi ya da sektirilen FLIX canlı duruyor (dokununca tepki veriyor), sağ altta büyük sarı **OYNA** düğmesi, üstte toplam tüy (oyun parası). Alt sırada küçük düğmeler: Dükkân, Görevler/Günlük hediye, Ayarlar. Tek bakışta ne yapılacağı belli olmalı.
- İlk açılışta 3-5 adımlık kısa **"Nasıl oynanır"** (atlanabilir), ilk oyunda bir kez çıkan ipucu baloncukları.
- **Dil: Türkçe ve İngilizce.** Bütün metinler tek bir `TEXT = {tr: {...}, en: {...}}` sözlüğünde. Ayarlardan değişir, ilk açılışta telefonun diline göre seçilir.
- Ayarlar: dil, ses aç/kapa, müzik aç/kapa, titreşim aç/kapa, grafik kalitesi (Yüksek / Hızlı), satın alımları geri yükle, gizlilik politikası linki.

**Telefon kuralları**
- iPhone'da **dikey** oynanır, tek elle, sağ başparmakla.
- **Ana düğmeler sağ altta.** Sağ üste sadece duraklat gibi ikincil şeyler konur (oraya başparmak yetişmiyor).
- `env(safe-area-inset-*)` ile çentiğe ve alt çubuğa taşmasın. `<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">` olsun, yoksa iPhone Safari sayfayı 980 piksel genişlikte çizer.
- Oyun Claude uygulamasının içinde artifact olarak da denenir. Claude uygulaması ekranı döndürmez, o yüzden oyun her zaman dikey tasarlanır. Telefon yatay tutulursa oyun kendini dikey düzende ortalar (ya da "telefonu dik tut" kartı gösterir).
- Dokunma tepkisi anında. Uygulamada titreşim (haptic): hafif vuruşta hafif, önemli anda orta, kaybedince güçlü.
- Uygulama arka plana geçince oyun duraklar ve ses kapanır, geri gelince ses açılır.
- Performans: iPhone'da 60 fps. Piksel oranı en fazla 2, tek gölge ışığı, paylaşılan geometri ve malzemeler. Duraklatma ve menü ekranlarında sahne daha seyrek çizilir.

**Ses**
- Sesler Web Audio ile kodun içinde üretilir (ses dosyası gerekmez). Aynı anda en fazla 12 ses.

**Ekonomi (Kick Up ile aynı mantık)**
- Oyun parası **tüy**. Oynayarak kazanılır: maç/tur sonu, görevler, günlük hediye, ödüllü reklam.
- Tüyle kostümler, izler ve sahneler açılır. Nadirlik seviyeleri: Sıradan 150-300, Nadir 500-800, Destansı 1.200-1.800, Efsane 3.000-4.500 tüy, Mitik 15.000 tüy. İlk 3 kostüm kolay gelsin, sonrası dikleşsin. Dükkânda yeni şey açılabilecekse "Yeni" rozeti.
- **Para sadece hızlandırır.** Oyunun kendisi (bütün modlar, bölümler, haritalar) ücretsiz ve oynayarak açılır. Parayla sadece tüy paketi, kozmetik, Başlangıç Paketi ve Reklamsız alınır.
- Kayıt `localStorage` ile, bütün erişimler `try/catch` içinde. Kayıt sürüm numarası taşısın, eski kayıt yeni sürüme taşınsın.

**Reklam (uygulamada Google AdMob, web'de Flix tanıtım kartı)**
- Ödüllü reklam sadece oyuncu basarsa açılır: "Kaldığın yerden devam" (tur başına 1 kez) ve "Tüyleri 2 katına çıkar". Ödül yalnızca reklam sonuna kadar izlenince verilir. Reklam hazır değilse kısa bir mesaj çıkar.
- Tur arası reklam en erken 3. bitmiş oyundan sonra, sonra her 3 oyunda bir, en fazla 90 saniyede bir. Sadece sonuç ekranından çıkarken, oyun sırasında asla. Reklamsız satın alındıysa hiç çıkmaz.
- Web sürümünde (GitHub Pages, artifact) reklam ağı yok. Aynı yerlerde gerçek FLIX oyuncağının kendi tanıtım kartı çıkar (flixtoysofficial.com'a gider).
- Hazır altyapı: `altyapi/www/ads.js` ve `altyapi/www/ads-config.js` (Flix Kick Up'ta çalışan dosyalar). Reklam tempo ve ödül ayarları oyunun içinde tek yerde `AD_CFG` nesnesinde.

**Satın alma (uygulamada App Store, web'de açıkça "DEMO" yazan ekran)**
- Hazır altyapı: `altyapi/www/native-bridge.js` (cordova-plugin-purchase v13). Oyun `window.FlixNative.buy(id)`, `restore()`, `price(id)` çağırır. Ürün kimlikleri bu dosyadaki iki listeye yazılır.
- Tüyler, Apple işlemi onaylanınca işlem kimliğiyle **bir kez** eklenir (`window.__fkuGrant` benzeri bir fonksiyon, oyunun kendi adıyla). Ödeme yarıda kalırsa ya da "Satın Alma İzni" sonradan onaylanırsa ürün bir sonraki açılışta yine gelir, iki kez gelmez. Düğmeye iki kez basmak iki ödeme açmaz.
- Fiyatlar mağazadan TL olarak okunur, oyunda sabit fiyat yazılmaz.

**iOS uygulaması (Capacitor 8)**
- `altyapi/` klasörü Flix Kick Up'ın çalışan uygulama iskeleti: `capacitor.config.json`, `package.json`, `ios.sh`, `tools/build_www.py` (web oyununu `www/index.html`'e çevirir, Google Fonts'u yerel dosyalarla değiştirir), `tools/ios_setup.py` (dikey kilit, sadece iPhone, durum çubuğu gizli, ikon, açılış ekranı, AdMob kimliği), `tools/minify.js`. İçlerindeki "Kick Up" adlarını ve `kickup_` kimliklerini bu oyununkilerle değiştir.
- Oyun tek HTML dosyası olarak geliştirilir (Three.js **r128**, `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js`). Uygulamada Three.js ve fontlar `www/` içine konur, dışarıdan hiçbir şey yüklenmez.
- Uygulama ikonu `store/icon-1024.png`, açılış ekranı `store/acilis_ekrani.png` (pakette hazır).
- TestFlight'a yükleme: Mac'te `./ios.sh yukle 1.0`. Mac yoksa GitHub Actions bulut Mac'i (Kaan'ın flix-kick-up reposundaki `ios-testflight.yml` iş akışına bu oyun için yeni bir `app` seçeneği eklenir). Apple hesabı, App Store Connect kaydı ve API anahtarı Kaan'da.

**Test**
- `?bot=1` ile oyunu kendi kendine oynayan bir **bot modu** olsun. Denge ayarları bot sonuçlarıyla yapılır (ör. zayıf, orta, iyi bot ortalama kaç tur dayanıyor).
- Her sürümde Playwright ile: bütün ekranlar TR ve EN, 3 ekran boyu (iPhone SE, iPhone 15, iPhone 15 Pro Max), konsolda hata yok, 10 oyunluk bellek sızıntısı testi.

**Teslim**
- Her adımın sonunda oynanabilir bir sürüm ver ve ne değiştiğini kısaca, Türkçe yaz.
- Sürümleri `oyun-v1.html`, `oyun-v2.html` diye sakla, sonuncusu her zaman `index.html`.
- Bitmiş her sürüm GitHub'a da yüklenir (GitHub Pages linkiyle telefonda Safari'de denenir).

**Arayüz kiti (taslak görsellerinde kullanılan, birebir başlangıç noktası)**

Bütün Flix oyunları aynı düğme ve kart dilini kullanır. Bu CSS'i temel al:

```css
:root{--red:#e22511;--navy:#022753;--yel:#ffc20e;--ink:#1b1330;--cream:#fbf6ea}
.big{font-family:'Barlow Condensed';font-style:italic;font-weight:900;line-height:.9;letter-spacing:.5px}
.lbl{font-size:11px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase;opacity:.85}
.pill{background:rgba(2,39,83,.86);color:#fff;border-radius:14px;padding:7px 12px;font-weight:700;box-shadow:0 2px 0 rgba(0,0,0,.25)}
/* ana düğme: sarı, lacivert kenarlı, altında koyu sarı "kalınlık" gölgesi, basınca 4px aşağı iner */
.btn{border-radius:50%;color:var(--navy);background:var(--yel);border:3px solid var(--navy);box-shadow:0 6px 0 #c78f00,0 10px 18px rgba(0,0,0,.3)}
.btn:active{transform:translateY(4px);box-shadow:0 2px 0 #c78f00,0 4px 8px rgba(0,0,0,.3)}
.btn.sec{background:#fff;box-shadow:0 5px 0 #b9c2d0,0 8px 14px rgba(0,0,0,.25)}
.btn.red{background:var(--red);color:#fff;box-shadow:0 6px 0 #8f150a,0 10px 18px rgba(0,0,0,.3)}
/* büyük oyun içi yazı: sarı, lacivert kontur ve gölge (MÜKEMMEL!, DİREKT VURUŞ!, x2 HIZ) */
.call{font-family:'Barlow Condensed';font-style:italic;font-weight:900;font-size:44px;color:var(--yel);-webkit-text-stroke:2px var(--navy);paint-order:stroke fill;text-shadow:0 4px 0 var(--navy)}
.tag{display:inline-block;background:var(--red);color:#fff;font-weight:800;font-size:12px;letter-spacing:1.5px;padding:5px 10px;border-radius:8px;transform:rotate(-3deg)}
```

- Yerleşim: sağ altta büyük ana düğme (yaklaşık 96 px), solunda ikincil düğme (74 px). Sol üstte skor ya da durum, sağ üstte duraklat (40 px kare, lacivert).
- Dükkân kartları: krem zemin, lacivert ince kenar, üstte 3D önizleme (bir kez çizilip saklanan küçük resim), altta ad ve fiyat. Nadirlik rengi kartın üst şeridinde: Sıradan gri `#9aa4b4`, Nadir mavi `#1f6fd1`, Destansı mor `#8a3ffc`, Efsane turuncu `#ff8a1a`, Mitik kırmızı-altın degrade.
- Tüy simgesi: küçük üç renkli tüy yelpazesi (SVG), oyun parasının her yerdeki simgesi. Emoji kullanma.

**Ekonomi şablonu (bütün Flix oyunlarında aynı iskelet, sayılar oyuna göre ayarlanır)**

- **Günlük hediye:** 7 günlük merdiven, her gün açınca: 50, 75, 100, 150, 200, 300 tüy, 7. gün bir Nadir kostüm (hepsi açılmışsa 800 tüy). Bir gün kaçarsa merdiven başa döner. Ödüllü reklamla günün hediyesi 2 katı.
- **Görevler:** her gün 3 görev (kolay 40, orta 80, zor 150 tüy). Haftalık 1 büyük görev 600 tüy.
- **Hedeflenen kazanç:** reklamsız, satın almasız normal oyuncu günde 15-20 dakikada yaklaşık 400-600 tüy toplar. Böylece ilk Nadir 1 günde, ilk Destansı 3-4 günde, ilk Efsane 1-2 haftada, Mitik 1-2 ayda açılır.
- **İlk 10 dakika:** ilk maç/tur bitince bir hediye kostüm, ilk dükkân ziyaretinde ilk kostümü alacak kadar tüy. Oyuncu ilk oturumda en az bir şey açmalı.
- **Fiyat çapası:** dükkânda en pahalı paket (50.000 tüy, 49,99 $) en altta, "En çok satan" etiketi 3.500 tüylük pakette, "En iyi değer" etiketi 18.000 tüylük pakette.
- **Başlangıç Paketi:** sadece ilk 3 gün ana ekranda büyük kart olarak görünür (geri sayımlı), sonra dükkânda kalır. Tek sefer alınır, geri yüklenebilir.
- **Satın alma ekranı:** Apple'ın kendi penceresi açılır. Başarılıysa tüy sayacı yukarı sayarak dolar, konfeti ve titreşim.

**Reklam yerleşim tablosu (uygulama)**

| Yer | Tür | Kural |
|---|---|---|
| Tur/maç sonu "Tüyleri 2 katına çıkar" | Ödüllü | İsteğe bağlı, her turda 1 kez |
| Kaybedince "Kaldığın yerden devam" | Ödüllü | İsteğe bağlı, tur başına 1 kez (maç oyunlarında yok) |
| Günlük hediye "2 katı al" | Ödüllü | Günde 1 kez |
| Dükkân "Ücretsiz tüy" | Ödüllü | Günde en fazla 5 kez, her biri 50 tüy, aralarında 10 dakika |
| Sonuç ekranından çıkış | Geçiş (interstitial) | En erken 3. oyundan sonra, her 3 oyunda bir, en az 90 saniye arayla, Reklamsız alındıysa hiç |
| Ana ekran altı | Banner | Kapalı başlar (`bannerEnabled: false`), açılırsa sadece ana ekranda |

- İlk açılışta önce Google'ın onay penceresi, sonra bir kez iPhone'un "takip izni" sorusu (`requestTracking`). Hayır denirse reklamlar kişiselleştirilmeden çalışır.
- Reklam kimlikleri boşsa ya da biçimi yanlışsa Google'ın test reklamı çıkar (yanlış uygulama kimliği uygulamayı çökertir, `ios_setup.py` bunu kontrol eder). Gerçek kimlikleri Kaan AdMob'da açar.
- App Store Connect > Uygulama Gizliliği: "Cihaz Kimliği: reklam için, takip için" ve "Satın alımlar: uygulama işlevi için" işaretlenir. Gizlilik politikası sayfası gerekir (Kaan'ın flix-kick-up reposundaki `gizlilik.html` örnek alınır).

