// FLIX oyuncağının 3D modeli (Three.js r128). makeToy() bir THREE.Group döndürür: yuvarlak kırmızı gövde + mavi, yeşil, sarı üç yaprak tüy + koyu mürekkep dış çizgisi.
// Kullanım: const toy = makeToy(); scene.add(toy);
const NAVY = 0x022753, RED = 0xe22511, YEL = 0xffc20e, INKC = 0x1b1330;
const OUT = {};
function outlineMat(th, col) {
  const k = th + '_' + col; if (OUT[k]) return OUT[k];
  const m = new THREE.MeshBasicMaterial({color: col === undefined ? INKC : col, side: THREE.BackSide});
  m.onBeforeCompile = (s) => { s.vertexShader = s.vertexShader.replace('#include <begin_vertex>', 'vec3 transformed = position + normal * ' + th.toFixed(4) + ';'); };
  return (OUT[k] = m);
}
function ink(obj, th, col, skip) {
  const list = []; obj.traverse((o) => { if (o.isMesh && !o.userData.noInk && !(o.material && (o.material.transparent || o.material.isMeshBasicMaterial))) list.push(o); });
  for (const m of list) { if (skip && skip(m)) continue; const s = new THREE.Mesh(m.geometry, outlineMat(th, col)); s.userData.noInk = true; m.add(s); }
  return obj;
}
function std(col, r, m) { return new THREE.MeshStandardMaterial({color: col, roughness: r === undefined ? 0.6 : r, metalness: m || 0}); }
function mesh(geo, mat, x, y, z, par) { const o = new THREE.Mesh(geo, mat); o.position.set(x || 0, y || 0, z || 0); o.castShadow = true; o.receiveShadow = true; if (par) par.add(o); return o; }
function leafGeo(L, Wd, bend) {
  const g = new THREE.PlaneGeometry(1, 1, 8, 20); const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const u = p.getX(i) + 0.5, v = p.getY(i) + 0.5; // u across, v along
    const wv = Math.pow(Math.sin(Math.PI * Math.min(1, v * 0.96 + 0.04)), 0.75) * (1 - v * 0.25);
    const x = (u - 0.5) * Wd * wv, y = v * L;
    const cup = -Math.pow((u - 0.5) * 2, 2) * 0.06 * Wd * wv * 3; // slight cupping across the leaf
    const z = bend * v * v * L + cup;
    p.setXYZ(i, x, y, z);
  }
  g.computeVertexNormals(); return g;
}
function makeToy(opt) {
  opt = opt || {};
  const g = new THREE.Group();
  const baseCol = opt.base || RED;
  const prof = []; for (let i = 0; i <= 16; i++) { const a = -Math.PI / 2 + (i / 16) * Math.PI / 2; prof.push(new THREE.Vector2(Math.cos(a) * 0.36, Math.sin(a) * 0.3 + 0.3)); }
  prof.push(new THREE.Vector2(0.36, 0.42)); prof.push(new THREE.Vector2(0.3, 0.46)); prof.push(new THREE.Vector2(0.0, 0.46));
  const base = mesh(new THREE.LatheGeometry(prof, 40), new THREE.MeshStandardMaterial({color: baseCol, roughness: 0.35, emissive: baseCol, emissiveIntensity: 0.15}), 0, 0, 0, g);
  const band = mesh(new THREE.TorusGeometry(0.365, 0.028, 10, 40), std(NAVY, 0.4), 0, 0.33, 0, g); band.rotation.x = Math.PI / 2;
  const band2 = mesh(new THREE.TorusGeometry(0.33, 0.018, 8, 40), std(0xffffff, 0.4), 0, 0.2, 0, g); band2.rotation.x = Math.PI / 2; band2.scale.set(1.02, 1.02, 1);
  const cols = opt.feathers || [0x1f6fd1, 0x2fa84f, 0xffc20e];
  const lg = leafGeo(1.25, 0.62, -0.12);
  const fe = [];
  [-1, 0, 1].forEach((k, i) => {
    const piv = new THREE.Group(); piv.position.set(k * 0.12, 0.42, 0); g.add(piv);
    piv.rotation.z = -k * 0.42; piv.rotation.x = k === 0 ? -0.08 : 0.06;
    const m = mesh(lg, new THREE.MeshStandardMaterial({color: cols[i], roughness: 0.45, emissive: cols[i], emissiveIntensity: 0.32, side: THREE.DoubleSide}), 0, 0, 0, piv);
    const rib = mesh(new THREE.CylinderGeometry(0.012, 0.02, 1.05, 6), std(0xffffff, 0.5), 0, 0.52, 0.012, piv); rib.userData.noInk = true;
    fe.push(piv);
  });
  ink(g, 0.022);
  g.userData.fe = fe;
  if (opt.scale) g.scale.setScalar(opt.scale);
  return g;
}

