# Flix Süzülüş: uygulama altyapısı

Bu klasördeki dosyalar Flix Kick Up'ın App Store'a hazır, çalışan iPhone uygulamasından alındı ve Flix Süzülüş için adları değiştirildi. Claude bunları baştan yazmasın, uyarlasın.

- `intro.html`: "FLIX TOYS presents" açılış ekranı. Oyun HTML'inin `<body>` etiketinin hemen ardına aynen yapıştırılır.
- `capacitor.config.json`: uygulama kimliği `com.flixtoys.suzulus`, adı Flix Süzülüş.
- `package.json`: Capacitor 8, AdMob, satın alma (cordova-plugin-purchase), titreşim, durum çubuğu eklentileri. `npm run build` web oyununu `www/index.html`'e çevirir.
- `www/ads.js`: AdMob reklam servisi (ödüllü, geçiş, banner). Web'de hiçbir şey yapmaz, oyun o zaman Flix tanıtım kartını gösterir.
- `www/ads-config.js`: reklam kimlikleri ve anahtarları. Boş kimlik = Google test reklamı.
- `www/native-bridge.js`: App Store satın alma ve titreşim. Ürün kimlikleri (suzulus_...) en üstteki iki listede. Oyunun içinde `window.__fkuGrant(id, islemKimligi)` fonksiyonu tanımlanmalı (adını değiştirirsen iki yerde de değiştir).
- `tools/build_www.py`: web oyununu uygulamaya çevirir, Google Fonts yerine yerel font dosyalarını koyar, dış bağlantı kalırsa durur. Kaynak dosya adını (`flix-kick-up.html`) bu oyununkiyle değiştir, online dosyaları yoksa o satırı sil. Three.js'i de `www/three.min.js` olarak yerel yap.
- `tools/ios_setup.py`: dikey kilit, sadece iPhone, durum çubuğu gizli, ikon, açılış ekranı, AdMob uygulama kimliği, sürüm numarası.
- `tools/minify.js`: uygulamadaki dosyayı küçültür.
- `ios.sh`: Mac'te `./ios.sh simulator` (simülatörde aç), `./ios.sh yukle 1.0` (TestFlight'a yükle).
- `store/icon-1024.png`: başlangıç uygulama ikonu. `store/acilis_ekrani.png`: iPhone açılış ekranı (FLIX TOYS presents).

Apple tarafı (geliştirici hesabı, uygulama kaydı, API anahtarı, uygulama içi ürünler) Kaan'ın hesabında yapılır.
