# FLIX SÜZÜLÜŞ: Claude'a yapıştırılacak oyun tarifi

> Bu metnin tamamını Claude'a yapıştır. Aynı mesaja paketteki şu dosyaları da ekle:
> **flix-suzulus-taslak.jpg** (oynanış taslağı), **flix-logo-kirmizi.png** (logo), **flix-oyuncak-modeli.js** (oyuncağın 3D modeli), **app-ikonu-1024.png** (başlangıç ikonu), **altyapi/** klasöründeki dosyalar (açılış ekranı, reklam, satın alma ve iOS iskeleti).

---

Merhaba Claude. Senden **FLIX SÜZÜLÜŞ** adında, iPhone'da dikey oynanan sakin ama hızlı bir 3D düşüş/süzülme oyunu yapmanı istiyorum. Ekteki **flix-suzulus-taslak.jpg** oyunun nasıl görüneceğini gösteren taslak: kamera açısı, arayüz yerleşimi ve renkler bu taslağa yakın olsun. Önce oynanabilir bir prototip yap, sonra aşağıdaki adımlarla geliştirelim.

## 1. Oyunun fikri (tek cümle)

Gökyüzünden aşağı süzül: tüylü Flix oyuncağını yönlendir, altın halkalardan geç, adalara çarpmadan **en derine in**.

Flix oyuncağının tüyleri gerçekte onu yavaşlatıp süzdürüyor. Bu düşüş hissi oyunun kendisi.

## 2. Kahraman

- Kahraman **Flix oyuncağının kendisi** (`makeToy()`, ekteki **flix-oyuncak-modeli.js**). Modeli kullan, bozma.
- Düşerken gövde aşağıda, tüyler yukarıda açık durur. Tüylerin açılıp kapanması `toy.userData.fe` içindeki üç tüy pivotuyla: **AÇ** basılıyken tüyler geniş yelpaze olur, **DAL** basılıyken tüyler kapanıp birleşir ve oyuncak ok gibi olur. Hafif sallanma ve dönme animasyonu.

## 3. Oynanış

- Kamera oyuncağın biraz arkasında ve üstünde, aşağı ve ileri bakar (taslaktaki gibi, FOV yaklaşık 58). Dünya aşağı doğru ilerler: oyuncak sürekli düşer.
- **Yön:** ekranın herhangi bir yerinde parmağı sürükle, oyuncak o yöne kayar (sol-sağ ve yukarı-aşağı ekran düzleminde). Parmak bırakılınca yavaşça ortalanır. Tek parmakla oynanır.
- **DAL** (sağ altta büyük kırmızı düğme, basılı tut): hız artar, halkalar daha çok puan verir ama kontrol zorlaşır.
- **AÇ** (yanındaki beyaz düğme, basılı tut): tüyler açılır, hız düşer, dar yerlerden geçmek kolaylaşır. **Tüy enerjisi** sınırlı, düğmenin çevresinde halka olarak görünür, halkalardan geçtikçe dolar.
- **Halkalar:** sarı halka puan ve hız verir, art arda geçince **halka zinciri** büyür (x2, x3...). Beyaz halka zinciri korur. **Altın halka** nadir çıkar, birkaç saniye x2 hız ve puan.
- **Engeller:** uçan adalar (kenarları kaya, üstleri çimen ve ağaç), bulut kümeleri (görüşü kapatır, çarpmaz), rüzgâr akımları (görünür beyaz çizgiler, oyuncağı yana iter), kuş sürüleri, balonlar, uçurtma ipleri. Daha derinde: fırtına bulutları ve şimşek, gece katmanı, uzay katmanı.
- **Toplananlar:** yolda mavi, yeşil, sarı tüyler (oyun parası), kalkan (bir çarpmayı affeder), mıknatıs (tüyleri çeker).
- **Bitiş:** adaya ya da sert engele çarpınca tur biter. Ekranın sağ kenarında dikey **derinlik göstergesi**: bir sonraki katmana ne kadar kaldığı ve rekorunun nerede olduğu (küçük bayrak).
- **Puan:** metre cinsinden derinlik + halka puanları. Sol üstte büyük "1.284 m", altında toplanan tüy.

## 4. Katmanlar (dünya derinleştikçe değişir)

1. **Gündüz Gökyüzü** (0-500 m): mavi gök, pamuk bulutlar, yeşil adalar.
2. **Gün Batımı** (500-1.200 m): turuncu-pembe gök, balonlar, kuşlar.
3. **Fırtına** (1.200-2.000 m): koyu bulutlar, şimşek uyarısı, güçlü rüzgâr.
4. **Gece** (2.000-3.000 m): yıldızlar, ışıklı fenerli adalar, ateş böcekleri.
5. **Uzay** (3.000 m ve sonrası): yerçekimi azalır, gezegen parçaları, meteorlar.
- Katmanlar arası geçişte kısa "GÜN BATIMI" yazısı ve renk geçişi. Zorluk derinlikle yavaşça artar.

## 5. Modlar

1. **Sonsuz Düşüş** (ana mod): en derine in, rekorunu kır.
2. **Günlük Parkur:** her gün aynı tohumla üretilen aynı parkur, herkes için aynı. 3 hak. Günlük sıralama (ilk sürümde cihazdaki sıralama, sonra online).
3. **Görevler:** her gün 3 görev ("Tek turda 20 halka", "Fırtına katmanına ulaş", "Hiç AÇ kullanmadan 500 m"). Görevler tüy verir.
4. **Koleksiyon:** her katmanda gizli bir **Flix kartı** var. 5 kartı toplayan özel kostüm açar.

## 6. Ekonomi ve dükkân

- Tüy kazanma: yolda toplanan tüyler, her 100 m için 5 tüy, görevler, günlük hediye, ödüllü reklam.
- Tur bitince ödüllü reklam: **"Kaldığın yerden devam"** (tur başına 1 kez, kalkanla yeniden başlar) ve **"Tüyleri 2 katına çıkar"**.
- **Dükkân sekmeleri:** Oyuncaklar (gövde ve tüy renkleri: Klasik, Okyanus, Orman, Altın, Gece, Kristal, Lav...), İzler (düşüş izi: tüy, yıldız, gökkuşağı, alev), Gökyüzü temaları (sadece görünüş).
- Nadirlik ve fiyatlar ev standartlarındaki gibi (bölüm A). Mitik: **Ejderha FLIX** oyuncağı (kanatlı tüyler) 15.000 tüy.

## 7. Uygulama içi ürünler (App Store Connect'te aynı kimliklerle açılacak)

| Kimlik | Tür | Fiyat | İçerik |
|---|---|---|---|
| `suzulus_starter` | Tüketilemez | 2,99 $ | Başlangıç Paketi: 2.500 tüy + Kristal FLIX oyuncağı |
| `suzulus_noads` | Tüketilemez | 2,99 $ | Reklamsız: tur arası reklamları kaldırır |
| `suzulus_feathers_500` | Tüketilebilir | 0,99 $ | 500 tüy |
| `suzulus_feathers_1200` | Tüketilebilir | 1,99 $ | 1.200 tüy |
| `suzulus_feathers_3500` | Tüketilebilir | 4,99 $ | 3.500 tüy |
| `suzulus_feathers_8000` | Tüketilebilir | 9,99 $ | 8.000 tüy |
| `suzulus_feathers_18000` | Tüketilebilir | 19,99 $ | 18.000 tüy |
| `suzulus_feathers_50000` | Tüketilebilir | 49,99 $ | 50.000 tüy |

## 8. Uygulama bilgileri

- **Ad:** Flix Süzülüş (İngilizce mağazada: Flix Glide) · **Paket kimliği (Bundle ID):** `com.flixtoys.suzulus` · **SKU:** `suzulus1` · iPhone, dikey.
- **Alt başlık (TR):** Gökyüzünden süzül, en derine in! · **(EN):** Glide down the sky, go deeper!
- **Kısa açıklama (TR):** Tüylü FLIX'i gökyüzünden aşağı süzdür! Parmağınla yön ver, altın halkalardan geç, DAL ile hızlan, AÇ ile yavaşla. Uçan adalardan, fırtınadan ve meteorlardan kaç, her gün yeni parkurda rekor kır.
- **Ekran görüntüleri (6,9" 1290x2796, TR ve EN):** 1 ana ekran, 2 altın halkadan geçiş, 3 fırtına katmanı, 4 uzay katmanı, 5 günlük parkur ve sıralama, 6 dükkân. Görseller gerçek oyundan alınır, üstüne büyük italik başlık.
- **App ikonu:** pakette başlangıç ikonu var (**app-ikonu-1024.png**: tüyleri açık Flix oyuncağı altın halkadan geçiyor, arkada mavi gök ve bulutlar). Oyun bitince gerçek oyun sahnesinden yeniden çiz.

## 8a. Görsel tarz (ayrıntılı)

- **Hava:** ferah, sakin, rüya gibi ama hız hissi güçlü. Taslaktaki gibi derin mavi üstten açık maviye ve şeftaliye inen gökyüzü, uzakta sise karışan adalar (Fog 30-110).
- **Kamera:** oyuncağın 3-5 birim arkasında ve üstünde, aşağı-ileri bakar. Hız arttıkça FOV 58'den 70'e açılır (hız hissi), DAL'da hafif titreme, AÇ'ta kamera yavaşça geri çekilir. Halka geçişinde 0.1 saniyelik "nefes" yakınlaşması.
- **Oyuncak:** ekrandaki tek büyük kahraman, ekranın orta-alt kısmında. Tüyler açıkken yelpaze, DAL'da birleşik ok. Arkasında tüy renklerinde üç ince iz (mavi, yeşil, sarı).
- **Halkalar:** sarı halka parlak, hafif ışıklı (emissive), lacivert mürekkep kenar. Altın halka daha kalın, dönen ışık şeridi. Beyaz halka yarı saydam. Geçince halka dağılıp küçük tüy parçacıklarına dönüşür.
- **Adalar:** ters koni kaya gövde (kahverengi `#8a6a52`), üstte yeşil çimen diski (`#59b04a`), küçük koni ağaçlar, ara ara ev ve deniz feneri. Kalın mürekkep çizgisi (0.04).
- **Hız çizgileri:** oyuncağın etrafında beyaz ince çizgiler, hızla sayıları artar. Rüzgâr akımları görünür beyaz akıntı şeritleri.
- **Katman paletleri:** Gündüz (`#3c6fd8` → `#a9d4ff` → `#ffe2b8`), Gün Batımı (`#2f3f9a` → `#f39a5e` → `#ffd49a`), Fırtına (`#2a2f4a` → `#5a6080` → `#8a90a8`, şimşek flaşı beyaz), Gece (`#0b1630` → `#1b2d6b`, sarı fenerler), Uzay (`#05040c` → `#1b1340`, mor ve camgöbeği gezegenler).
- **Arayüz:** sol üstte büyük "1.284 m" ve altında tüy hapı, sağ üstte halka zinciri kartı ve duraklat, sağ kenarda dikey derinlik göstergesi (kırmızı nokta sen, küçük bayrak rekorun). Sağ altta kırmızı DAL, solunda beyaz AÇ.

## 8b. Dükkân kataloğu (ilk sürüm)

| Sekme | Ürün | Nadirlik | Fiyat (tüy) | Nasıl açılır |
|---|---|---|---|---|
| Oyuncak | Klasik | Sıradan | ücretsiz | başlangıç |
| Oyuncak | Okyanus 200, Orman 250, Pamuk Şeker 300 | Sıradan | 200-300 | dükkân |
| Oyuncak | Gece 600, Buz 700, Şeftali 800 | Nadir | 600-800 | dükkân |
| Oyuncak | Lav 1.400, Galaksi 1.800 | Destansı | 1.400-1.800 | dükkân |
| Oyuncak | Kristal | Efsane | 3.500 | dükkân / Başlangıç Paketi |
| Oyuncak | Altın | Efsane | 4.000 | 5 koleksiyon kartını topla |
| Oyuncak | Ejderha FLIX (kanatlı tüyler) | Mitik | 15.000 | dükkân |
| İz | Tüy (başlangıç), Yıldız 250, Kalp 300, Gökkuşağı 800, Alev 1.200, Kuyruklu Yıldız 1.800 | | | dükkân |
| Gökyüzü | Pembe Sabah 500, Kuzey Işıkları 1.500, Altın Saat 1.800 (sadece görünüş) | | | dükkân |

## 8c. Ekonomi ve reklam ayarları (kodda tek yerde)

```js
const ECON = {per100m: 5, featherPickup: 1, ringChainBonus: [0, 0, 2, 4, 8], missions: [40, 80, 150], weekly: 600, daily: [50,75,100,150,200,300,'nadir']};
const AD_CFG = {revivePerRun: 1, doubleReward: true, interstitialFirstAfter: 3, interstitialEvery: 3, interstitialMinGapSec: 90, freeFeathersPerDay: 5, freeFeathersAmount: 50, freeFeathersGapMin: 10};
```
Tur sonu ekranı sırası: derinlik, rekor mu (büyük "YENİ REKOR!"), kazanılan tüy, "KALDIĞIN YERDEN DEVAM ▶" (ödüllü, ilk 5 saniye, geri sayım halkasıyla), "2 KATINA ÇIKAR ▶", sağ altta TEKRAR. Tur arası reklam sadece TEKRAR/MENÜ'ye basınca, kurala uyuyorsa.

## 9. Yapım sırası

1. **Prototip:** sürekli düşüş, sürükleyerek yön, DAL ve AÇ, halkalar, adalar, çarpınca bitiş, derinlik sayacı. Telefonda dene, düşüş hızını ve kontrol hissini ayarla.
2. **Oyun hissi:** rüzgâr sesi (hızla değişen), halka "ding" sesleri (zincirde tonu yükselen), hız çizgileri, kamera titremesi, tüy izleri.
3. **Ekranlar:** FLIX TOYS presents, Kick Up tarzı ana ekran (arkada süzülen oyuncak), nasıl oynanır, tur sonu, ayarlar, TR/EN.
4. **İçerik:** 5 katman, engel çeşitleri, kalkan ve mıknatıs, günlük parkur (tohumlu üretim), görevler, koleksiyon kartları.
5. **Ekonomi:** tüy, dükkân, reklamlar (web'de Flix kartı), satın almalar (web'de DEMO).
6. **Mağaza hazırlığı:** Capacitor iOS paketi (`altyapi/`), ikon, açılış ekranı, ekran görüntüleri, mağaza metni TR/EN.
7. **Sonra:** online günlük sıralama (küçük bir sunucu ya da Supabase).

**Tahmini iş:** 6 adım, her biri yaklaşık 1 Claude oturumu (toplam 6-9 oturum). Beş fikir içinde en hızlı yapılacak oyun. En önemli iş, uzun süre tutması için günlük parkur, görevler ve koleksiyonun iyi çalışması.

Önce **1. adımla** başla.

---

## A. Flix ev standartları (bütün Flix oyunlarında aynı, bunlara mutlaka uy)

Bu oyun, aynı markanın yayındaki diğer oyunlarıyla (Flix Kick Up, Flix Arkana, Flix Atış, Flix Sen Olsaydın) aynı aileden olacak. Aşağıdaki kurallar o oyunlarda denendi ve kabul edildi.

**Marka**
- **Flix** bir oyuncak markası (flixtoysofficial.com, Amazon'da da satılıyor). Ürün ayakla sektirilen tüylü bir oyuncak: altta yuvarlak kırmızı bir gövde, üstünde yelpaze gibi açılmış **3 yaprak şeklinde tüy (mavi, yeşil, sarı)**. Tüy sayısı her zaman 3, gövde her zaman 1.
- Logo: ekteki **flix-logo-kirmizi.png** (kırmızı zemin üstünde). Ana ekranda, açılışta ve mağaza görsellerinde bu logo kullanılır. Logoyu yeniden çizme, dosyayı kullan.
- Renkler: kırmızı `#e22511`, lacivert `#022753`, sarı `#ffc20e`, mürekkep çizgisi `#1b1330`. Tüyler: mavi `#1f6fd1`, yeşil `#2fa84f`, sarı `#ffc20e`.
- Yazı tipleri: başlık ve rakamlar **Barlow Condensed** (italik, 800-900), metinler **Rubik**. Uygulamada internetsiz çalışsın diye font dosyaları uygulamanın içine konur.
- 3D oyuncak: ekteki **flix-oyuncak-modeli.js** (`makeToy()`). Bunu kullan, bozma. Tüy pivotları `toy.userData.fe` içinde.

**Görünüm**
- Temiz, sevimli **çizgi film (toon) 3D**: koyu ince mürekkep dış çizgisi (`ink()`), yumuşak gölge, sıcak ışık, canlı ama yorucu olmayan renkler.
- **Yapay zekâ yapımı gibi görünmesin.** İstenmeyenler: hazır şablon görünümü, mor-mavi degrade arka planlar, emoji ikonlar, her yerde aynı yuvarlak kartlar, rastgele parlama efektleri, gereksiz kalabalık. Az ama büyük ve net öğeler.
- Animasyonlar hızlı ve abartısız: ekran geçişleri 0.3 saniyenin altında.

**Ekranlar ve akış**
- Açılışta 2 saniyelik **"FLIX TOYS presents"** ekranı. Hazır kodu ekteki `altyapi/intro.html` içinde, `<body>`'nin en başına aynen yapıştırılır. Dokununca geçilir.
- **Kick Up tarzı ana ekran**: kırmızı zemin, üstte Flix logosu, büyük italik oyun adı, ortada oyunun 3D sahnesi ya da sektirilen FLIX canlı duruyor (dokununca tepki veriyor), sağ altta büyük sarı **OYNA** düğmesi, üstte toplam tüy (oyun parası). Alt sırada küçük düğmeler: Dükkân, Görevler/Günlük hediye, Ayarlar. Tek bakışta ne yapılacağı belli olmalı.
- İlk açılışta 3-5 adımlık kısa **"Nasıl oynanır"** (atlanabilir), ilk oyunda bir kez çıkan ipucu baloncukları.
- **Dil: Türkçe ve İngilizce.** Bütün metinler tek bir `TEXT = {tr: {...}, en: {...}}` sözlüğünde. Ayarlardan değişir, ilk açılışta telefonun diline göre seçilir.
- Ayarlar: dil, ses aç/kapa, müzik aç/kapa, titreşim aç/kapa, grafik kalitesi (Yüksek / Hızlı), satın alımları geri yükle, gizlilik politikası linki.

**Telefon kuralları**
- iPhone'da **dikey** oynanır, tek elle, sağ başparmakla.
- **Ana düğmeler sağ altta.** Sağ üste sadece duraklat gibi ikincil şeyler konur (oraya başparmak yetişmiyor).
- `env(safe-area-inset-*)` ile çentiğe ve alt çubuğa taşmasın. `<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">` olsun, yoksa iPhone Safari sayfayı 980 piksel genişlikte çizer.
- Oyun Claude uygulamasının içinde artifact olarak da denenir. Claude uygulaması ekranı döndürmez, o yüzden oyun her zaman dikey tasarlanır. Telefon yatay tutulursa oyun kendini dikey düzende ortalar (ya da "telefonu dik tut" kartı gösterir).
- Dokunma tepkisi anında. Uygulamada titreşim (haptic): hafif vuruşta hafif, önemli anda orta, kaybedince güçlü.
- Uygulama arka plana geçince oyun duraklar ve ses kapanır, geri gelince ses açılır.
- Performans: iPhone'da 60 fps. Piksel oranı en fazla 2, tek gölge ışığı, paylaşılan geometri ve malzemeler. Duraklatma ve menü ekranlarında sahne daha seyrek çizilir.

**Ses**
- Sesler Web Audio ile kodun içinde üretilir (ses dosyası gerekmez). Aynı anda en fazla 12 ses.

**Ekonomi (Kick Up ile aynı mantık)**
- Oyun parası **tüy**. Oynayarak kazanılır: maç/tur sonu, görevler, günlük hediye, ödüllü reklam.
- Tüyle kostümler, izler ve sahneler açılır. Nadirlik seviyeleri: Sıradan 150-300, Nadir 500-800, Destansı 1.200-1.800, Efsane 3.000-4.500 tüy, Mitik 15.000 tüy. İlk 3 kostüm kolay gelsin, sonrası dikleşsin. Dükkânda yeni şey açılabilecekse "Yeni" rozeti.
- **Para sadece hızlandırır.** Oyunun kendisi (bütün modlar, bölümler, haritalar) ücretsiz ve oynayarak açılır. Parayla sadece tüy paketi, kozmetik, Başlangıç Paketi ve Reklamsız alınır.
- Kayıt `localStorage` ile, bütün erişimler `try/catch` içinde. Kayıt sürüm numarası taşısın, eski kayıt yeni sürüme taşınsın.

**Reklam (uygulamada Google AdMob, web'de Flix tanıtım kartı)**
- Ödüllü reklam sadece oyuncu basarsa açılır: "Kaldığın yerden devam" (tur başına 1 kez) ve "Tüyleri 2 katına çıkar". Ödül yalnızca reklam sonuna kadar izlenince verilir. Reklam hazır değilse kısa bir mesaj çıkar.
- Tur arası reklam en erken 3. bitmiş oyundan sonra, sonra her 3 oyunda bir, en fazla 90 saniyede bir. Sadece sonuç ekranından çıkarken, oyun sırasında asla. Reklamsız satın alındıysa hiç çıkmaz.
- Web sürümünde (GitHub Pages, artifact) reklam ağı yok. Aynı yerlerde gerçek FLIX oyuncağının kendi tanıtım kartı çıkar (flixtoysofficial.com'a gider).
- Hazır altyapı: `altyapi/www/ads.js` ve `altyapi/www/ads-config.js` (Flix Kick Up'ta çalışan dosyalar). Reklam tempo ve ödül ayarları oyunun içinde tek yerde `AD_CFG` nesnesinde.

**Satın alma (uygulamada App Store, web'de açıkça "DEMO" yazan ekran)**
- Hazır altyapı: `altyapi/www/native-bridge.js` (cordova-plugin-purchase v13). Oyun `window.FlixNative.buy(id)`, `restore()`, `price(id)` çağırır. Ürün kimlikleri bu dosyadaki iki listeye yazılır.
- Tüyler, Apple işlemi onaylanınca işlem kimliğiyle **bir kez** eklenir (`window.__fkuGrant` benzeri bir fonksiyon, oyunun kendi adıyla). Ödeme yarıda kalırsa ya da "Satın Alma İzni" sonradan onaylanırsa ürün bir sonraki açılışta yine gelir, iki kez gelmez. Düğmeye iki kez basmak iki ödeme açmaz.
- Fiyatlar mağazadan TL olarak okunur, oyunda sabit fiyat yazılmaz.

**iOS uygulaması (Capacitor 8)**
- `altyapi/` klasörü Flix Kick Up'ın çalışan uygulama iskeleti: `capacitor.config.json`, `package.json`, `ios.sh`, `tools/build_www.py` (web oyununu `www/index.html`'e çevirir, Google Fonts'u yerel dosyalarla değiştirir), `tools/ios_setup.py` (dikey kilit, sadece iPhone, durum çubuğu gizli, ikon, açılış ekranı, AdMob kimliği), `tools/minify.js`. İçlerindeki "Kick Up" adlarını ve `kickup_` kimliklerini bu oyununkilerle değiştir.
- Oyun tek HTML dosyası olarak geliştirilir (Three.js **r128**, `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js`). Uygulamada Three.js ve fontlar `www/` içine konur, dışarıdan hiçbir şey yüklenmez.
- Uygulama ikonu `store/icon-1024.png`, açılış ekranı `store/acilis_ekrani.png` (pakette hazır).
- TestFlight'a yükleme: Mac'te `./ios.sh yukle 1.0`. Mac yoksa GitHub Actions bulut Mac'i (Kaan'ın flix-kick-up reposundaki `ios-testflight.yml` iş akışına bu oyun için yeni bir `app` seçeneği eklenir). Apple hesabı, App Store Connect kaydı ve API anahtarı Kaan'da.

**Test**
- `?bot=1` ile oyunu kendi kendine oynayan bir **bot modu** olsun. Denge ayarları bot sonuçlarıyla yapılır (ör. zayıf, orta, iyi bot ortalama kaç tur dayanıyor).
- Her sürümde Playwright ile: bütün ekranlar TR ve EN, 3 ekran boyu (iPhone SE, iPhone 15, iPhone 15 Pro Max), konsolda hata yok, 10 oyunluk bellek sızıntısı testi.

**Teslim**
- Her adımın sonunda oynanabilir bir sürüm ver ve ne değiştiğini kısaca, Türkçe yaz.
- Sürümleri `oyun-v1.html`, `oyun-v2.html` diye sakla, sonuncusu her zaman `index.html`.
- Bitmiş her sürüm GitHub'a da yüklenir (GitHub Pages linkiyle telefonda Safari'de denenir).

**Arayüz kiti (taslak görsellerinde kullanılan, birebir başlangıç noktası)**

Bütün Flix oyunları aynı düğme ve kart dilini kullanır. Bu CSS'i temel al:

```css
:root{--red:#e22511;--navy:#022753;--yel:#ffc20e;--ink:#1b1330;--cream:#fbf6ea}
.big{font-family:'Barlow Condensed';font-style:italic;font-weight:900;line-height:.9;letter-spacing:.5px}
.lbl{font-size:11px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase;opacity:.85}
.pill{background:rgba(2,39,83,.86);color:#fff;border-radius:14px;padding:7px 12px;font-weight:700;box-shadow:0 2px 0 rgba(0,0,0,.25)}
/* ana düğme: sarı, lacivert kenarlı, altında koyu sarı "kalınlık" gölgesi, basınca 4px aşağı iner */
.btn{border-radius:50%;color:var(--navy);background:var(--yel);border:3px solid var(--navy);box-shadow:0 6px 0 #c78f00,0 10px 18px rgba(0,0,0,.3)}
.btn:active{transform:translateY(4px);box-shadow:0 2px 0 #c78f00,0 4px 8px rgba(0,0,0,.3)}
.btn.sec{background:#fff;box-shadow:0 5px 0 #b9c2d0,0 8px 14px rgba(0,0,0,.25)}
.btn.red{background:var(--red);color:#fff;box-shadow:0 6px 0 #8f150a,0 10px 18px rgba(0,0,0,.3)}
/* büyük oyun içi yazı: sarı, lacivert kontur ve gölge (MÜKEMMEL!, DİREKT VURUŞ!, x2 HIZ) */
.call{font-family:'Barlow Condensed';font-style:italic;font-weight:900;font-size:44px;color:var(--yel);-webkit-text-stroke:2px var(--navy);paint-order:stroke fill;text-shadow:0 4px 0 var(--navy)}
.tag{display:inline-block;background:var(--red);color:#fff;font-weight:800;font-size:12px;letter-spacing:1.5px;padding:5px 10px;border-radius:8px;transform:rotate(-3deg)}
```

- Yerleşim: sağ altta büyük ana düğme (yaklaşık 96 px), solunda ikincil düğme (74 px). Sol üstte skor ya da durum, sağ üstte duraklat (40 px kare, lacivert).
- Dükkân kartları: krem zemin, lacivert ince kenar, üstte 3D önizleme (bir kez çizilip saklanan küçük resim), altta ad ve fiyat. Nadirlik rengi kartın üst şeridinde: Sıradan gri `#9aa4b4`, Nadir mavi `#1f6fd1`, Destansı mor `#8a3ffc`, Efsane turuncu `#ff8a1a`, Mitik kırmızı-altın degrade.
- Tüy simgesi: küçük üç renkli tüy yelpazesi (SVG), oyun parasının her yerdeki simgesi. Emoji kullanma.

**Ekonomi şablonu (bütün Flix oyunlarında aynı iskelet, sayılar oyuna göre ayarlanır)**

- **Günlük hediye:** 7 günlük merdiven, her gün açınca: 50, 75, 100, 150, 200, 300 tüy, 7. gün bir Nadir kostüm (hepsi açılmışsa 800 tüy). Bir gün kaçarsa merdiven başa döner. Ödüllü reklamla günün hediyesi 2 katı.
- **Görevler:** her gün 3 görev (kolay 40, orta 80, zor 150 tüy). Haftalık 1 büyük görev 600 tüy.
- **Hedeflenen kazanç:** reklamsız, satın almasız normal oyuncu günde 15-20 dakikada yaklaşık 400-600 tüy toplar. Böylece ilk Nadir 1 günde, ilk Destansı 3-4 günde, ilk Efsane 1-2 haftada, Mitik 1-2 ayda açılır.
- **İlk 10 dakika:** ilk maç/tur bitince bir hediye kostüm, ilk dükkân ziyaretinde ilk kostümü alacak kadar tüy. Oyuncu ilk oturumda en az bir şey açmalı.
- **Fiyat çapası:** dükkânda en pahalı paket (50.000 tüy, 49,99 $) en altta, "En çok satan" etiketi 3.500 tüylük pakette, "En iyi değer" etiketi 18.000 tüylük pakette.
- **Başlangıç Paketi:** sadece ilk 3 gün ana ekranda büyük kart olarak görünür (geri sayımlı), sonra dükkânda kalır. Tek sefer alınır, geri yüklenebilir.
- **Satın alma ekranı:** Apple'ın kendi penceresi açılır. Başarılıysa tüy sayacı yukarı sayarak dolar, konfeti ve titreşim.

**Reklam yerleşim tablosu (uygulama)**

| Yer | Tür | Kural |
|---|---|---|
| Tur/maç sonu "Tüyleri 2 katına çıkar" | Ödüllü | İsteğe bağlı, her turda 1 kez |
| Kaybedince "Kaldığın yerden devam" | Ödüllü | İsteğe bağlı, tur başına 1 kez (maç oyunlarında yok) |
| Günlük hediye "2 katı al" | Ödüllü | Günde 1 kez |
| Dükkân "Ücretsiz tüy" | Ödüllü | Günde en fazla 5 kez, her biri 50 tüy, aralarında 10 dakika |
| Sonuç ekranından çıkış | Geçiş (interstitial) | En erken 3. oyundan sonra, her 3 oyunda bir, en az 90 saniye arayla, Reklamsız alındıysa hiç |
| Ana ekran altı | Banner | Kapalı başlar (`bannerEnabled: false`), açılırsa sadece ana ekranda |

- İlk açılışta önce Google'ın onay penceresi, sonra bir kez iPhone'un "takip izni" sorusu (`requestTracking`). Hayır denirse reklamlar kişiselleştirilmeden çalışır.
- Reklam kimlikleri boşsa ya da biçimi yanlışsa Google'ın test reklamı çıkar (yanlış uygulama kimliği uygulamayı çökertir, `ios_setup.py` bunu kontrol eder). Gerçek kimlikleri Kaan AdMob'da açar.
- App Store Connect > Uygulama Gizliliği: "Cihaz Kimliği: reklam için, takip için" ve "Satın alımlar: uygulama işlevi için" işaretlenir. Gizlilik politikası sayfası gerekir (Kaan'ın flix-kick-up reposundaki `gizlilik.html` örnek alınır).

