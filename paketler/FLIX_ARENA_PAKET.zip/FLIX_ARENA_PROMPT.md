# FLIX ARENA: Claude'a yapıştırılacak oyun tarifi

> Bu metnin tamamını Claude'a yapıştır. Aynı mesaja paketteki şu dosyaları da ekle:
> **flix-arena-taslak.jpg** (oynanış taslağı), **flix-logo-kirmizi.png** (logo), **flix-oyuncak-modeli.js** (oyuncağın 3D modeli), **flix-kahraman-modeli.js** (FLIX kahramanının 3D modeli), **app-ikonu-1024.png** (başlangıç ikonu), **altyapi/** klasöründeki dosyalar (açılış ekranı, reklam, satın alma ve iOS iskeleti).

---

Merhaba Claude. Senden **FLIX ARENA** adında, iPhone'da dikey oynanan 4 kişilik bir 3D parti/dövüş oyunu yapmanı istiyorum. Ekteki **flix-arena-taslak.jpg** oyunun nasıl görüneceğini gösteren taslak: kamera açısı, arayüz yerleşimi ve renkler bu taslağa yakın olsun. Önce oynanabilir bir prototip yap, sonra aşağıdaki adımlarla geliştirelim.

## 1. Oyunun fikri (tek cümle)

4 kahraman, havada yüzen altıgen bir arena: arenada uçuşan Flix oyuncağını yakala, rakibine vur, onu **arenadan aşağı düşür**. Zemin parça parça çöker, son kalan kazanır.

## 2. Karakterler

- Dört oyuncu **FLIX kahramanı**: ekteki **flix-kahraman-modeli.js** dosyasındaki `hero(skin)` modeli (Flix Arkana oyunundaki FLIX karakteri). Modeli kullan, bozma. Pozlar `pose(H, {...})`, yüz ifadeleri `R.flixFaces` (happy, blink, shout, hurt).
- Kahramanlar (her biri bir kostüm ve bir özel güç):
  - **FLIX** (Kraliyet, kırmızı): dengeli. Güç: **Tüy Kalkanı** (2 saniye vurulmaz).
  - **Buzul** (mavi-beyaz): yavaş ama ağır. Güç: **Buz Zemini** (etrafındaki karolar kayar).
  - **Ejder** (yeşil-siyah): sert vurur. Güç: **Ateş Vuruşu** (bir sonraki vuruş 2 kat savurur).
  - **Altın** (sarı): hızlı. Güç: **Atılma** (kısa mesafe hızlı kaçış).
  - Sonra açılanlar: **Neon** (pembe), **KICK** ve **FLICK** (Arkana'daki diğer kahramanlar, aynı modelin farklı renk ve taç biçimiyle).
- Ortada **Flix oyuncağı** (`makeToy()`) uçuşur. Vurulunca gövde öne, tüyler arkada, hızla gider.

## 3. Oynanış

- Arena: altıgen karolardan yapılmış yuvarlak bir platform, gökyüzünde yüzüyor. Dış halka kırmızı karolar (kenar uyarısı). Kamera yukarıdan ve önden, bütün arena tek ekrana sığar (taslaktaki gibi, FOV yaklaşık 44).
- **Kontroller:**
  - Sol altta **joystick** (sol başparmak): yürü ve koş. Bu oyunda iki el kullanılır, ana düğmeler yine sağ altta.
  - Sağ altta büyük sarı **VUR**: oyuncak yakınındaysa joystick yönüne vurur. Basılı tutup bırakınca daha sert.
  - Yanında beyaz **ZIPLA**: zıpla, çöken karonun üstünden atla, vuruştan kaç.
  - Üstünde küçük **GÜÇ** düğmesi: kahramanın özel gücü, dolum halkasıyla (vuruş yaptıkça dolar).
- **Vuruş:** oyuncak bir rakibe çarparsa rakip vuruş yönünde **geri savrulur**. Her darbede savrulma artar (hasar yüzdesi, kahraman kartında "%45" gibi görünür). Yüzde arttıkça daha uzağa uçar.
- **Düşme:** arenanın dışına savrulan kahraman 1 can kaybeder ve 2 saniye sonra ortada yeniden doğar (kısa süre vurulmaz). **3 can** biterse elenir.
- **Çöken zemin:** maç 2 dakika. 30. saniyeden sonra rastgele karolar önce titrer ve kızarır, 1,5 saniye sonra düşer. Son 30 saniyede dış halka tamamen çöker, arena küçülür.
- **Güçlendirmeler:** arenaya ara ara tüy düşer: mavi (hız), yeşil (savrulmaya dayanıklılık), sarı (güç halkasını doldurur).
- **Kazanma:** son kalan kazanır. Süre biterse en çok canı olan, eşitse en düşük yüzdeli kazanır.
- **Botlar:** 3 bot rakip. Davranış: oyuncağa koş, rakibi kenara doğru hedefle, çöken karodan kaç, düşük yüzdeliyken saldır, yüksek yüzdeliyken ortaya çekil. Kolay, Orta, Zor seviyeleri. Botlar akıllı ama insan gibi hata yapmalı.
- HUD (taslaktaki gibi): üstte 4 kahraman kartı (ad, renk, can, yüzde), ortada süre ve "zemin çöküyor" uyarısı, vuruşta büyük "DİREKT VURUŞ!" yazısı.

## 4. Modlar

1. **Hızlı Maç:** 3 bot, rastgele arena.
2. **Kupa Yolu:** 10 maçlık seri, her maçta botlar zorlaşır. Her 5 maçta bir kahraman ya da kostüm ödülü.
3. **Takım Maçı:** 2'ye 2 (sen + bot dostun, 2 bot rakip).
4. **Günlük Kaos:** her gün değişen kural ("Az yerçekimi", "İki oyuncak", "Buz zemini her yerde").
5. **Online 4 kişi:** ilk sürümde "Yakında". Ciddi sunucu işi (gerçek zamanlı, sunucu fiziği ya da kilitli adım). İkinci aşamada Flix Kick Up'taki WebSocket sunucusu üzerine.

## 5. Arenalar

Arenalar tüyle açılır, her birinin küçük bir kuralı var:
- **Çatı Arenası** (başlangıç): İstanbul çatıları üstünde, bacalar, martılar. Normal kurallar.
- **Buz Pisti:** karolar kaygan, kahramanlar fren yapamaz.
- **Lunapark:** ortada dönen bir çark platformu, ara ara konfeti topu ateşleyen top.
- **Volkan:** lav fışkıran karolar, sıcak karoya basan hızla kızarır.
- **Uzay İstasyonu:** az yerçekimi, uzun zıplamalar, savrulma çok uzun.

## 6. Ekonomi ve dükkân

- Tüy kazanma: galibiyet 80, 2. sıra 40, 3. sıra 25, 4. sıra 15, her düşürülen rakip 10, görevler, günlük hediye, ödüllü reklam.
- Elenince ödüllü reklam: **"Kaldığın yerden devam"** (maç başına 1 kez, 1 canla geri dön) ve maç sonunda **"Tüyleri 2 katına çıkar"**.
- **Dükkân sekmeleri:** Kahramanlar (Neon, KICK, FLICK, tüyle açılır), Kostümler (her kahramana 4-6 renk), Oyuncaklar (Flix oyuncağının renkleri), Zafer dansları (kazanınca yapılan hareket), Arenalar.
- Nadirlik ve fiyatlar ev standartlarındaki gibi (bölüm A). Mitik: **Ejderha FLIX** kostümü 15.000 tüy.
- **Sezon** (ikinci aşama): 30 günlük ücretsiz ödül yolu (her maç sezon puanı verir), isteğe bağlı ücretli **Altın Yol** ile ekstra kostümler.

## 7. Uygulama içi ürünler (App Store Connect'te aynı kimliklerle açılacak)

| Kimlik | Tür | Fiyat | İçerik |
|---|---|---|---|
| `arena_starter` | Tüketilemez | 2,99 $ | Başlangıç Paketi: 2.500 tüy + Neon kahramanı |
| `arena_noads` | Tüketilemez | 2,99 $ | Reklamsız: tur arası reklamları kaldırır |
| `arena_feathers_500` | Tüketilebilir | 0,99 $ | 500 tüy |
| `arena_feathers_1200` | Tüketilebilir | 1,99 $ | 1.200 tüy |
| `arena_feathers_3500` | Tüketilebilir | 4,99 $ | 3.500 tüy |
| `arena_feathers_8000` | Tüketilebilir | 9,99 $ | 8.000 tüy |
| `arena_feathers_18000` | Tüketilebilir | 19,99 $ | 18.000 tüy |
| `arena_feathers_50000` | Tüketilebilir | 49,99 $ | 50.000 tüy |
| `arena_goldpass` (sonra) | Tüketilemez, sezonluk | 4,99 $ | Altın Yol: o sezonun ekstra ödülleri |

## 8. Uygulama bilgileri

- **Ad:** Flix Arena · **Paket kimliği (Bundle ID):** `com.flixtoys.arena` · **SKU:** `arena1` · iPhone, dikey.
- **Alt başlık (TR):** Vur, savur, arenada son kalan sen ol! · **(EN):** Kick, knock, be the last one standing!
- **Kısa açıklama (TR):** Dört FLIX kahramanı, havada yüzen bir arena ve tek bir tüylü oyuncak! Oyuncağı yakala, rakiplerine vur, onları aşağı savur. Zemin çökerken son kalan sen ol. Kahramanları aç, kupaları topla.
- **Ekran görüntüleri (6,9" 1290x2796, TR ve EN):** 1 ana ekran, 2 DİREKT VURUŞ anı, 3 çöken zemin, 4 kahraman seçimi, 5 arenalar, 6 dükkân. Görseller gerçek oyundan alınır, üstüne büyük italik başlık.
- **App ikonu:** pakette başlangıç ikonu var (**app-ikonu-1024.png**: FLIX oyuncağı Buzul'a vurmuş, altıgen arena, mor gök). Oyun bitince gerçek oyun sahnesinden yeniden çiz.

## 8a. Görsel tarz (ayrıntılı)

- **Hava:** renkli, şenlikli, parti oyunu. Taslaktaki gibi lacivertten mora ve mercana inen akşam göğü, altta pembe bulut denizi. Arena gökyüzünde yüzen bir oyuncak kutusu gibi.
- **Kamera:** yukarıdan yaklaşık 45 derece, hafif önden, bütün arena ekrana sığar. Kahramanlar arenanın kenarına yaklaşınca kamera hafifçe geri çekilir. DİREKT VURUŞ'ta 0.2 saniye yavaş çekim ve 0.1 saniyelik sarsıntı, son kalan kazanınca kamera kazanana döner.
- **Arena:** altıgen karolar, krem (`#f4ead8`) çoğunluk, ara ara sarı karolar, dış halka kırmızı (`#e22511`) kenar uyarısı. Lacivert mürekkep çizgisi (0.03). Altta koyu mor kaya gövde. Çökecek karo önce titrer, sonra turuncu-kırmızıya döner, sonra aşağı düşüp bulutlara kaybolur.
- **Kahramanlar:** FLIX modeli kalın mürekkep çizgisiyle, her kahraman kendi kostüm rengiyle. Altlarında kendi renginde halka (kim nerede, tek bakışta). Vurulunca "hurt" yüzü, savrulurken pelerin dalgalanır, arenadan düşerken küçülerek bulutlara düşer ve "puf" bulutu.
- **Oyuncak:** vurulunca vuranın renginde iz bırakır (kim vurdu belli olur). Çok hızlıyken tüyler arkaya yapışır.
- **Efektler (abartısız):** vuruşta sarı-beyaz yıldız patlaması, savrulmada hız çizgileri, düşüşte bulut puf'u, kazananın üstünde konfeti. Ekranda aynı anda en fazla 2 büyük yazı.
- **Arena paletleri:** Çatı (terrakota `#c8643c` kenar, akşam göğü), Buz Pisti (buz `#d8ecff`, parlak yansıma), Lunapark (sarı-kırmızı çizgili karolar, ışık zinciri), Volkan (koyu taş `#3a2a2a`, lav `#ff6a1a` çatlaklar), Uzay İstasyonu (metal `#aab2c0`, camgöbeği ışıklar, yıldızlı gök).
- **Arayüz:** üstte yan yana 4 kahraman kartı (taslaktaki gibi: renk noktası, ad, kalp canlar, yüzde). Seninki beyaz ve sarı çerçeveli. Ortada süre hapı. Sol altta yarı saydam beyaz joystick, sağ altta sarı VUR, solunda beyaz ZIPLA, VUR'un üstünde küçük GÜÇ düğmesi.

## 8b. Dükkân kataloğu (ilk sürüm)

| Sekme | Ürün | Nadirlik | Fiyat (tüy) | Nasıl açılır |
|---|---|---|---|---|
| Kahraman | FLIX, Buzul, Ejder, Altın | | ücretsiz | başlangıç |
| Kahraman | Neon | Nadir | 800 | dükkân / Başlangıç Paketi |
| Kahraman | KICK | Destansı | 1.800 | dükkân / Kupa Yolu 5. maç |
| Kahraman | FLICK | Efsane | 3.500 | dükkân / Kupa Yolu 10. maç |
| Kostüm | her kahramana 4-6 renk: Sıradan 150-300, Nadir 500-800, Destansı 1.200-1.800, Efsane 3.000-4.500 | | | dükkân |
| Kostüm | Ejderha FLIX (kanatlı pelerin, alev taç) | Mitik | 15.000 | dükkân |
| Oyuncak | Klasik, Okyanus, Orman, Gece, Kristal, Lav | Sıradan-Destansı | 150-1.800 | dükkân |
| Zafer dansı | El sallama (başlangıç), Takla 300, Robot 600, Moonwalk 1.200, Tüy yağmuru 3.000 | | | dükkân |
| Arena | Buz Pisti 500, Lunapark 800, Volkan 1.500, Uzay İstasyonu 1.800 | | | dükkân |

## 8c. Ekonomi ve reklam ayarları (kodda tek yerde)

```js
const ECON = {place: [80, 40, 25, 15], knockout: 10, cupEvery5: 'kahraman', missions: [40, 80, 150], weekly: 600, daily: [50,75,100,150,200,300,'nadir']};
const AD_CFG = {revivePerMatch: 1, doubleReward: true, interstitialFirstAfter: 3, interstitialEvery: 3, interstitialMinGapSec: 90, freeFeathersPerDay: 5, freeFeathersAmount: 50, freeFeathersGapMin: 10};
```
Elenince: "KALDIĞIN YERDEN DEVAM ▶" (ödüllü, maç başına 1, 1 canla ortada doğar) ya da "İZLE" (maçı seyirci olarak bitir). Maç sonu ekranı: 1-4 sıralama kürsüsü (kazanan zafer dansı yapar), kazanılan tüy, "2 KATINA ÇIKAR ▶", sağ altta TEKRAR. Tur arası reklam sadece TEKRAR/MENÜ'ye basınca, kurala uyuyorsa.

## 9. Yapım sırası

1. **Prototip:** arena, 1 kahraman + 3 bot, joystick, VUR, ZIPLA, oyuncak fiziği, savrulma yüzdesi, düşme ve can. Telefonda dene, vuruş ve savrulma hissini ayarla.
2. **Arena ve botlar:** çöken zemin, güçlendirmeler, özel güçler, 3 bot seviyesi. Bot testleriyle denge (`?bot=1` ile 4 bot birbiriyle oynar).
3. **Oyun hissi:** vuruş sesi ve yavaş çekim anı, kamera sarsıntısı, düşenin çığlığı, konfeti, zafer dansı.
4. **Ekranlar:** FLIX TOYS presents, Kick Up tarzı ana ekran (arkada arenada dans eden kahramanlar), kahraman seçimi, nasıl oynanır, maç sonu sıralaması, ayarlar, TR/EN.
5. **İçerik:** Kupa Yolu, Takım Maçı, Günlük Kaos, 5 arena, 7 kahraman.
6. **Ekonomi:** tüy, dükkân, reklamlar (web'de Flix kartı), satın almalar (web'de DEMO).
7. **Mağaza hazırlığı:** Capacitor iOS paketi (`altyapi/`), ikon, açılış ekranı, ekran görüntüleri, mağaza metni TR/EN.
8. **Sonra:** online 4 kişi ve sezon sistemi.

**Tahmini iş:** 7 adım, her biri 1-3 Claude oturumu (toplam yaklaşık 12-18 oturum). Beş fikir içinde en zor oyun: kalabalık sahnenin telefonda 60 fps çalışması ve 3 botun akıllı davranması en çok emek isteyen kısımlar. Online 4 kişi ayrı ve büyük bir aşama.

Önce **1. adımla** başla.

---

## A. Flix ev standartları (bütün Flix oyunlarında aynı, bunlara mutlaka uy)

Bu oyun, aynı markanın yayındaki diğer oyunlarıyla (Flix Kick Up, Flix Arkana, Flix Atış, Flix Sen Olsaydın) aynı aileden olacak. Aşağıdaki kurallar o oyunlarda denendi ve kabul edildi.

**Marka**
- **Flix** bir oyuncak markası (flixtoysofficial.com, Amazon'da da satılıyor). Ürün ayakla sektirilen tüylü bir oyuncak: altta yuvarlak kırmızı bir gövde, üstünde yelpaze gibi açılmış **3 yaprak şeklinde tüy (mavi, yeşil, sarı)**. Tüy sayısı her zaman 3, gövde her zaman 1.
- Logo: ekteki **flix-logo-kirmizi.png** (kırmızı zemin üstünde). Ana ekranda, açılışta ve mağaza görsellerinde bu logo kullanılır. Logoyu yeniden çizme, dosyayı kullan.
- Renkler: kırmızı `#e22511`, lacivert `#022753`, sarı `#ffc20e`, mürekkep çizgisi `#1b1330`. Tüyler: mavi `#1f6fd1`, yeşil `#2fa84f`, sarı `#ffc20e`.
- Yazı tipleri: başlık ve rakamlar **Barlow Condensed** (italik, 800-900), metinler **Rubik**. Uygulamada internetsiz çalışsın diye font dosyaları uygulamanın içine konur.
- 3D oyuncak: ekteki **flix-oyuncak-modeli.js** (`makeToy()`). Bunu kullan, bozma. Tüy pivotları `toy.userData.fe` içinde.

**Görünüm**
- Temiz, sevimli **çizgi film (toon) 3D**: koyu ince mürekkep dış çizgisi (`ink()`), yumuşak gölge, sıcak ışık, canlı ama yorucu olmayan renkler.
- **Yapay zekâ yapımı gibi görünmesin.** İstenmeyenler: hazır şablon görünümü, mor-mavi degrade arka planlar, emoji ikonlar, her yerde aynı yuvarlak kartlar, rastgele parlama efektleri, gereksiz kalabalık. Az ama büyük ve net öğeler.
- Animasyonlar hızlı ve abartısız: ekran geçişleri 0.3 saniyenin altında.

**Ekranlar ve akış**
- Açılışta 2 saniyelik **"FLIX TOYS presents"** ekranı. Hazır kodu ekteki `altyapi/intro.html` içinde, `<body>`'nin en başına aynen yapıştırılır. Dokununca geçilir.
- **Kick Up tarzı ana ekran**: kırmızı zemin, üstte Flix logosu, büyük italik oyun adı, ortada oyunun 3D sahnesi ya da sektirilen FLIX canlı duruyor (dokununca tepki veriyor), sağ altta büyük sarı **OYNA** düğmesi, üstte toplam tüy (oyun parası). Alt sırada küçük düğmeler: Dükkân, Görevler/Günlük hediye, Ayarlar. Tek bakışta ne yapılacağı belli olmalı.
- İlk açılışta 3-5 adımlık kısa **"Nasıl oynanır"** (atlanabilir), ilk oyunda bir kez çıkan ipucu baloncukları.
- **Dil: Türkçe ve İngilizce.** Bütün metinler tek bir `TEXT = {tr: {...}, en: {...}}` sözlüğünde. Ayarlardan değişir, ilk açılışta telefonun diline göre seçilir.
- Ayarlar: dil, ses aç/kapa, müzik aç/kapa, titreşim aç/kapa, grafik kalitesi (Yüksek / Hızlı), satın alımları geri yükle, gizlilik politikası linki.

**Telefon kuralları**
- iPhone'da **dikey** oynanır, tek elle, sağ başparmakla.
- **Ana düğmeler sağ altta.** Sağ üste sadece duraklat gibi ikincil şeyler konur (oraya başparmak yetişmiyor).
- `env(safe-area-inset-*)` ile çentiğe ve alt çubuğa taşmasın. `<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">` olsun, yoksa iPhone Safari sayfayı 980 piksel genişlikte çizer.
- Oyun Claude uygulamasının içinde artifact olarak da denenir. Claude uygulaması ekranı döndürmez, o yüzden oyun her zaman dikey tasarlanır. Telefon yatay tutulursa oyun kendini dikey düzende ortalar (ya da "telefonu dik tut" kartı gösterir).
- Dokunma tepkisi anında. Uygulamada titreşim (haptic): hafif vuruşta hafif, önemli anda orta, kaybedince güçlü.
- Uygulama arka plana geçince oyun duraklar ve ses kapanır, geri gelince ses açılır.
- Performans: iPhone'da 60 fps. Piksel oranı en fazla 2, tek gölge ışığı, paylaşılan geometri ve malzemeler. Duraklatma ve menü ekranlarında sahne daha seyrek çizilir.

**Ses**
- Sesler Web Audio ile kodun içinde üretilir (ses dosyası gerekmez). Aynı anda en fazla 12 ses.

**Ekonomi (Kick Up ile aynı mantık)**
- Oyun parası **tüy**. Oynayarak kazanılır: maç/tur sonu, görevler, günlük hediye, ödüllü reklam.
- Tüyle kostümler, izler ve sahneler açılır. Nadirlik seviyeleri: Sıradan 150-300, Nadir 500-800, Destansı 1.200-1.800, Efsane 3.000-4.500 tüy, Mitik 15.000 tüy. İlk 3 kostüm kolay gelsin, sonrası dikleşsin. Dükkânda yeni şey açılabilecekse "Yeni" rozeti.
- **Para sadece hızlandırır.** Oyunun kendisi (bütün modlar, bölümler, haritalar) ücretsiz ve oynayarak açılır. Parayla sadece tüy paketi, kozmetik, Başlangıç Paketi ve Reklamsız alınır.
- Kayıt `localStorage` ile, bütün erişimler `try/catch` içinde. Kayıt sürüm numarası taşısın, eski kayıt yeni sürüme taşınsın.

**Reklam (uygulamada Google AdMob, web'de Flix tanıtım kartı)**
- Ödüllü reklam sadece oyuncu basarsa açılır: "Kaldığın yerden devam" (tur başına 1 kez) ve "Tüyleri 2 katına çıkar". Ödül yalnızca reklam sonuna kadar izlenince verilir. Reklam hazır değilse kısa bir mesaj çıkar.
- Tur arası reklam en erken 3. bitmiş oyundan sonra, sonra her 3 oyunda bir, en fazla 90 saniyede bir. Sadece sonuç ekranından çıkarken, oyun sırasında asla. Reklamsız satın alındıysa hiç çıkmaz.
- Web sürümünde (GitHub Pages, artifact) reklam ağı yok. Aynı yerlerde gerçek FLIX oyuncağının kendi tanıtım kartı çıkar (flixtoysofficial.com'a gider).
- Hazır altyapı: `altyapi/www/ads.js` ve `altyapi/www/ads-config.js` (Flix Kick Up'ta çalışan dosyalar). Reklam tempo ve ödül ayarları oyunun içinde tek yerde `AD_CFG` nesnesinde.

**Satın alma (uygulamada App Store, web'de açıkça "DEMO" yazan ekran)**
- Hazır altyapı: `altyapi/www/native-bridge.js` (cordova-plugin-purchase v13). Oyun `window.FlixNative.buy(id)`, `restore()`, `price(id)` çağırır. Ürün kimlikleri bu dosyadaki iki listeye yazılır.
- Tüyler, Apple işlemi onaylanınca işlem kimliğiyle **bir kez** eklenir (`window.__fkuGrant` benzeri bir fonksiyon, oyunun kendi adıyla). Ödeme yarıda kalırsa ya da "Satın Alma İzni" sonradan onaylanırsa ürün bir sonraki açılışta yine gelir, iki kez gelmez. Düğmeye iki kez basmak iki ödeme açmaz.
- Fiyatlar mağazadan TL olarak okunur, oyunda sabit fiyat yazılmaz.

**iOS uygulaması (Capacitor 8)**
- `altyapi/` klasörü Flix Kick Up'ın çalışan uygulama iskeleti: `capacitor.config.json`, `package.json`, `ios.sh`, `tools/build_www.py` (web oyununu `www/index.html`'e çevirir, Google Fonts'u yerel dosyalarla değiştirir), `tools/ios_setup.py` (dikey kilit, sadece iPhone, durum çubuğu gizli, ikon, açılış ekranı, AdMob kimliği), `tools/minify.js`. İçlerindeki "Kick Up" adlarını ve `kickup_` kimliklerini bu oyununkilerle değiştir.
- Oyun tek HTML dosyası olarak geliştirilir (Three.js **r128**, `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js`). Uygulamada Three.js ve fontlar `www/` içine konur, dışarıdan hiçbir şey yüklenmez.
- Uygulama ikonu `store/icon-1024.png`, açılış ekranı `store/acilis_ekrani.png` (pakette hazır).
- TestFlight'a yükleme: Mac'te `./ios.sh yukle 1.0`. Mac yoksa GitHub Actions bulut Mac'i (Kaan'ın flix-kick-up reposundaki `ios-testflight.yml` iş akışına bu oyun için yeni bir `app` seçeneği eklenir). Apple hesabı, App Store Connect kaydı ve API anahtarı Kaan'da.

**Test**
- `?bot=1` ile oyunu kendi kendine oynayan bir **bot modu** olsun. Denge ayarları bot sonuçlarıyla yapılır (ör. zayıf, orta, iyi bot ortalama kaç tur dayanıyor).
- Her sürümde Playwright ile: bütün ekranlar TR ve EN, 3 ekran boyu (iPhone SE, iPhone 15, iPhone 15 Pro Max), konsolda hata yok, 10 oyunluk bellek sızıntısı testi.

**Teslim**
- Her adımın sonunda oynanabilir bir sürüm ver ve ne değiştiğini kısaca, Türkçe yaz.
- Sürümleri `oyun-v1.html`, `oyun-v2.html` diye sakla, sonuncusu her zaman `index.html`.
- Bitmiş her sürüm GitHub'a da yüklenir (GitHub Pages linkiyle telefonda Safari'de denenir).

**Arayüz kiti (taslak görsellerinde kullanılan, birebir başlangıç noktası)**

Bütün Flix oyunları aynı düğme ve kart dilini kullanır. Bu CSS'i temel al:

```css
:root{--red:#e22511;--navy:#022753;--yel:#ffc20e;--ink:#1b1330;--cream:#fbf6ea}
.big{font-family:'Barlow Condensed';font-style:italic;font-weight:900;line-height:.9;letter-spacing:.5px}
.lbl{font-size:11px;font-weight:700;letter-spacing:1.4px;text-transform:uppercase;opacity:.85}
.pill{background:rgba(2,39,83,.86);color:#fff;border-radius:14px;padding:7px 12px;font-weight:700;box-shadow:0 2px 0 rgba(0,0,0,.25)}
/* ana düğme: sarı, lacivert kenarlı, altında koyu sarı "kalınlık" gölgesi, basınca 4px aşağı iner */
.btn{border-radius:50%;color:var(--navy);background:var(--yel);border:3px solid var(--navy);box-shadow:0 6px 0 #c78f00,0 10px 18px rgba(0,0,0,.3)}
.btn:active{transform:translateY(4px);box-shadow:0 2px 0 #c78f00,0 4px 8px rgba(0,0,0,.3)}
.btn.sec{background:#fff;box-shadow:0 5px 0 #b9c2d0,0 8px 14px rgba(0,0,0,.25)}
.btn.red{background:var(--red);color:#fff;box-shadow:0 6px 0 #8f150a,0 10px 18px rgba(0,0,0,.3)}
/* büyük oyun içi yazı: sarı, lacivert kontur ve gölge (MÜKEMMEL!, DİREKT VURUŞ!, x2 HIZ) */
.call{font-family:'Barlow Condensed';font-style:italic;font-weight:900;font-size:44px;color:var(--yel);-webkit-text-stroke:2px var(--navy);paint-order:stroke fill;text-shadow:0 4px 0 var(--navy)}
.tag{display:inline-block;background:var(--red);color:#fff;font-weight:800;font-size:12px;letter-spacing:1.5px;padding:5px 10px;border-radius:8px;transform:rotate(-3deg)}
```

- Yerleşim: sağ altta büyük ana düğme (yaklaşık 96 px), solunda ikincil düğme (74 px). Sol üstte skor ya da durum, sağ üstte duraklat (40 px kare, lacivert).
- Dükkân kartları: krem zemin, lacivert ince kenar, üstte 3D önizleme (bir kez çizilip saklanan küçük resim), altta ad ve fiyat. Nadirlik rengi kartın üst şeridinde: Sıradan gri `#9aa4b4`, Nadir mavi `#1f6fd1`, Destansı mor `#8a3ffc`, Efsane turuncu `#ff8a1a`, Mitik kırmızı-altın degrade.
- Tüy simgesi: küçük üç renkli tüy yelpazesi (SVG), oyun parasının her yerdeki simgesi. Emoji kullanma.

**Ekonomi şablonu (bütün Flix oyunlarında aynı iskelet, sayılar oyuna göre ayarlanır)**

- **Günlük hediye:** 7 günlük merdiven, her gün açınca: 50, 75, 100, 150, 200, 300 tüy, 7. gün bir Nadir kostüm (hepsi açılmışsa 800 tüy). Bir gün kaçarsa merdiven başa döner. Ödüllü reklamla günün hediyesi 2 katı.
- **Görevler:** her gün 3 görev (kolay 40, orta 80, zor 150 tüy). Haftalık 1 büyük görev 600 tüy.
- **Hedeflenen kazanç:** reklamsız, satın almasız normal oyuncu günde 15-20 dakikada yaklaşık 400-600 tüy toplar. Böylece ilk Nadir 1 günde, ilk Destansı 3-4 günde, ilk Efsane 1-2 haftada, Mitik 1-2 ayda açılır.
- **İlk 10 dakika:** ilk maç/tur bitince bir hediye kostüm, ilk dükkân ziyaretinde ilk kostümü alacak kadar tüy. Oyuncu ilk oturumda en az bir şey açmalı.
- **Fiyat çapası:** dükkânda en pahalı paket (50.000 tüy, 49,99 $) en altta, "En çok satan" etiketi 3.500 tüylük pakette, "En iyi değer" etiketi 18.000 tüylük pakette.
- **Başlangıç Paketi:** sadece ilk 3 gün ana ekranda büyük kart olarak görünür (geri sayımlı), sonra dükkânda kalır. Tek sefer alınır, geri yüklenebilir.
- **Satın alma ekranı:** Apple'ın kendi penceresi açılır. Başarılıysa tüy sayacı yukarı sayarak dolar, konfeti ve titreşim.

**Reklam yerleşim tablosu (uygulama)**

| Yer | Tür | Kural |
|---|---|---|
| Tur/maç sonu "Tüyleri 2 katına çıkar" | Ödüllü | İsteğe bağlı, her turda 1 kez |
| Kaybedince "Kaldığın yerden devam" | Ödüllü | İsteğe bağlı, tur başına 1 kez (maç oyunlarında yok) |
| Günlük hediye "2 katı al" | Ödüllü | Günde 1 kez |
| Dükkân "Ücretsiz tüy" | Ödüllü | Günde en fazla 5 kez, her biri 50 tüy, aralarında 10 dakika |
| Sonuç ekranından çıkış | Geçiş (interstitial) | En erken 3. oyundan sonra, her 3 oyunda bir, en az 90 saniye arayla, Reklamsız alındıysa hiç |
| Ana ekran altı | Banner | Kapalı başlar (`bannerEnabled: false`), açılırsa sadece ana ekranda |

- İlk açılışta önce Google'ın onay penceresi, sonra bir kez iPhone'un "takip izni" sorusu (`requestTracking`). Hayır denirse reklamlar kişiselleştirilmeden çalışır.
- Reklam kimlikleri boşsa ya da biçimi yanlışsa Google'ın test reklamı çıkar (yanlış uygulama kimliği uygulamayı çökertir, `ios_setup.py` bunu kontrol eder). Gerçek kimlikleri Kaan AdMob'da açar.
- App Store Connect > Uygulama Gizliliği: "Cihaz Kimliği: reklam için, takip için" ve "Satın alımlar: uygulama işlevi için" işaretlenir. Gizlilik politikası sayfası gerekir (Kaan'ın flix-kick-up reposundaki `gizlilik.html` örnek alınır).

